# TITAN PRO V60 — Android APK project

## Build (Android Studio)
1. Install Android Studio (Koala or newer) + JDK 17.
2. File > Open > this folder. Let Gradle sync (internet needed the first time; Chaquopy downloads numpy/pandas wheels).
3. Build > Build APK(s).
4. APK: app/build/outputs/apk/debug/app-debug.apk -> copy to phone and install.

## Command line
    ./gradlew assembleDebug     (or: gradle assembleDebug)

## First run
- Allow "All files access" (the script only writes to /storage/emulated/0/KKK).
- First start takes 20-60 s (Python + pandas load), then the dashboard opens inside the app.
- Logs: Internal Storage/KKK/data/titan_engine.log

## Notes
- Your script is bundled unchanged as app/src/main/python/titan_app.py.
- Entry: titan_runner.py -> titan_app.run_titan(open_browser=False), served on 127.0.0.1:8080.
- If a pip package is unavailable for Python 3.12 in Chaquopy, set version = "3.11" in app/build.gradle.kts.

## Build without a computer setup (GitHub Actions)
1. Create a new GitHub repo, upload ALL files of this folder (including the hidden .github folder).
2. Open the Actions tab > "Build TITAN APK" > Run workflow (it also runs on every push).
3. After ~10 min, open the finished run > Artifacts > TITAN-APK > download app-debug.apk.

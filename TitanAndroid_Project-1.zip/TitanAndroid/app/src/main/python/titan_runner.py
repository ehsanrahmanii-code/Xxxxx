"""Starts the TITAN Flask dashboard inside the Android app (called from TitanService)."""
import os
import threading

_started = False
_lock = threading.Lock()


def start(port: int = 8080) -> str:
    global _started
    with _lock:
        if _started:
            return "already-running"
        _started = True
    os.environ["TITAN_PORT"] = str(port)
    try:
        import titan_app  # needs All-files access to /storage/emulated/0/KKK
        titan_app.run_titan(open_browser=False)  # blocks (waitress / flask)
        return "stopped"
    except Exception as exc:
        _started = False
        import traceback
        return "ERROR: " + repr(exc) + "\n" + traceback.format_exc()

package com.titan.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform

class TitanService : Service() {

    companion object {
        const val PORT = 8080
        @Volatile var lastError: String? = null
        @Volatile var running = false
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundCompat()
        if (!running) {
            running = true
            Thread({
                try {
                    if (!Python.isStarted()) Python.start(AndroidPlatform(applicationContext))
                    val res = Python.getInstance().getModule("titan_runner")
                        .callAttr("start", PORT).toString()
                    Log.i("TITAN", "runner finished: $res")
                    if (res.startsWith("ERROR")) lastError = res
                } catch (t: Throwable) {
                    lastError = t.toString()
                    Log.e("TITAN", "python crashed", t)
                } finally {
                    running = false
                }
            }, "titan-python").start()
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val chId = "titan_engine"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(chId, "TITAN Engine", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n: Notification = NotificationCompat.Builder(this, chId)
            .setContentTitle("TITAN is running")
            .setContentText("Analysis engine active on 127.0.0.1:$PORT")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(1, n)
        }
    }
}

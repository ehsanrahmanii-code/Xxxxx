package com.titan.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.InetSocketAddress
import java.net.Socket

class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var loaded = false
    @Volatile private var waiting = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        status = TextView(this).apply {
            setTextColor(0xFFE8F1FF.toInt()); setBackgroundColor(0xFF02060F.toInt())
            textSize = 16f; setPadding(48, 96, 48, 48)
            text = "TITAN is starting…"
        }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            visibility = View.GONE
        }
        val root = FrameLayout(this)
        root.addView(web); root.addView(status)
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        if (!hasStorageAccess()) {
            status.text = "TITAN stores everything in Internal Storage/KKK.\n\n" +
                "Please allow \"All files access\" for this app, then come back."
            requestStorageAccess()
            return
        }
        if (!TitanService.running) {
            ContextCompat.startForegroundService(this, Intent(this, TitanService::class.java))
        }
        waitForServerThenLoad()
    }

    private fun hasStorageAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)
        }
    }

    private fun waitForServerThenLoad() {
        if (loaded || waiting) return
        waiting = true
        Thread {
            var tries = 0
            while (tries < 240 && !loaded) {   // ~2 min: first launch imports pandas/numpy
                TitanService.lastError?.let { err ->
                    ui.post { status.text = "TITAN failed to start:\n\n$err" }
                    waiting = false
                    return@Thread
                }
                if (portOpen()) {
                    ui.post {
                        loaded = true
                        web.loadUrl("http://127.0.0.1:${TitanService.PORT}")
                        web.visibility = View.VISIBLE
                        status.visibility = View.GONE
                    }
                    waiting = false
                    return@Thread
                }
                tries++
                Thread.sleep(500)
            }
            ui.post { status.text = "Server did not respond. See Internal Storage/KKK/data/titan_engine.log" }
            waiting = false
        }.start()
    }

    private fun portOpen(): Boolean = try {
        Socket().use { it.connect(InetSocketAddress("127.0.0.1", TitanService.PORT), 300); true }
    } catch (e: Exception) { false }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (loaded && web.canGoBack()) web.goBack() else moveTaskToBack(true)
    }
}
